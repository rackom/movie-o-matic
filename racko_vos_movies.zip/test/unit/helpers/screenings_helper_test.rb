require 'test_helper'

class ScreeningsHelperTest < ActionView::TestCase
end
